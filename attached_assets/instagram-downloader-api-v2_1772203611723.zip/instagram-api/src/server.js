require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { v4: uuidv4 } = require('uuid');

const logger = require('./utils/logger');
const { errorHandler, notFoundHandler } = require('./middleware/errorHandler');
const { apiKeyAuth } = require('./middleware/auth');
const { stats: cacheStats } = require('./utils/cache');
const { proxyPool, sessionPool } = require('./core/httpEngine');

// Routes
const mediaRoutes    = require('./routes/media');
const userRoutes     = require('./routes/user');
const reelsRoutes    = require('./routes/reels');
const storiesRoutes  = require('./routes/stories');
const highlightsRoutes = require('./routes/highlights');
const searchRoutes   = require('./routes/search');
const hashtagRoutes  = require('./routes/hashtag');
const locationRoutes = require('./routes/location');

const app = express();
const PORT = process.env.PORT || 3000;
const V = process.env.API_VERSION || 'v1';

// ─── Security ─────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(compression());
app.set('trust proxy', 1);

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '*').split(',').map(s => s.trim());
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) cb(null, true);
    else cb(new Error('Not allowed by CORS'));
  },
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-api-key'],
}));

app.use(morgan('combined', { stream: { write: msg => logger.http(msg.trim()) } }));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Request ID
app.use((req, res, next) => {
  req.requestId = uuidv4();
  res.setHeader('X-Request-ID', req.requestId);
  res.setHeader('X-API-Version', V);
  next();
});

// Rate limiter
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  standardHeaders: true, legacyHeaders: false,
  keyGenerator: (req) => req.headers['x-api-key'] || req.ip,
  message: { success: false, error: 'Rate limit exceeded. See Retry-After header.' }
});
app.use(`/api/${V}`, limiter);

// ─── Public Endpoints ─────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({
  success: true, status: 'ok', version: V,
  uptime_seconds: Math.floor(process.uptime()),
  timestamp: new Date().toISOString(),
}));

app.get(`/api/${V}`, (req, res) => res.json({
  success: true,
  name: '📸 Instagram Downloader API',
  version: V,
  authentication: 'x-api-key header required for all /api/* routes',
  endpoints: {
    '── Media ───────────────────────────────': '',
    'GET  /api/v1/media':             '?url=<any_ig_url>[&quality=best|1080p|720p|480p|360p]',
    'POST /api/v1/media/batch':       'body: { urls: [...] } — up to 10 URLs',
    'GET  /api/v1/media/likers':      '?shortcode=<shortcode>',
    'GET  /api/v1/media/comments':    '?shortcode=<shortcode>[&cursor=...]',
    'GET  /api/v1/media/audio':       '?url=<reel_url>',
    '── Reels ───────────────────────────────': '',
    'GET  /api/v1/reels':             '?url=<reel_url>[&quality=best|1080p|720p]',
    'GET  /api/v1/reels/user':        '?username=<username>[&cursor=...]',
    'GET  /api/v1/reels/explore':     '[?cursor=...]',
    '── Stories & Highlights ────────────────': '',
    'GET  /api/v1/stories':           '?username=<username>  ⚠ Requires IG_SESSION_ID',
    'GET  /api/v1/highlights':        '?username=<username>',
    'GET  /api/v1/highlights/items':  '?id=<highlight_id>',
    '── User ────────────────────────────────': '',
    'GET  /api/v1/user':              '?username=<username>',
    'GET  /api/v1/user/posts':        '?username=<username>[&cursor=...]',
    'GET  /api/v1/user/followers':    '?username=<username>[&cursor=...]  ⚠ Requires auth',
    'GET  /api/v1/user/followings':   '?username=<username>[&cursor=...]  ⚠ Requires auth',
    '── Discovery ───────────────────────────': '',
    'GET  /api/v1/search':            '?q=<query>[&type=blended|user|hashtag|place]',
    'GET  /api/v1/hashtag':           '?tag=<hashtag>[&cursor=...]',
    'GET  /api/v1/location':          '?id=<location_id>[&cursor=...]',
    '── Admin ───────────────────────────────': '',
    'GET  /api/v1/status':            'Engine health, proxy/session pool status',
  },
  notes: [
    'All paginated endpoints return a "pagination" object with has_more and next_cursor',
    'All timestamps are returned as both Unix (taken_at) and ISO 8601 (taken_at_iso)',
    'Video downloads include all available qualities in video_downloads[]',
    'Pass cursor from pagination.next_cursor to get the next page',
  ],
}));

// ─── Status / Admin ───────────────────────────────────────────────────────
app.get(`/api/${V}/status`, apiKeyAuth, (req, res) => {
  const cs = cacheStats();
  res.json({
    success: true,
    server: {
      uptime_seconds: Math.floor(process.uptime()),
      node_version: process.version,
      memory_mb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      environment: process.env.NODE_ENV || 'development',
    },
    engine: {
      proxies_configured: proxyPool.count(),
      sessions_configured: sessionPool.count(),
      has_authentication: sessionPool.hasAuth(),
    },
    cache: {
      hits: cs.hits || 0,
      misses: cs.misses || 0,
      keys: cs.keys || 0,
      hit_rate: cs.hits ? `${((cs.hits / (cs.hits + cs.misses)) * 100).toFixed(1)}%` : '0%',
    },
  });
});

// ─── Protected API Routes ─────────────────────────────────────────────────
app.use(`/api/${V}/media`,       apiKeyAuth, mediaRoutes);
app.use(`/api/${V}/reels`,       apiKeyAuth, reelsRoutes);
app.use(`/api/${V}/stories`,     apiKeyAuth, storiesRoutes);
app.use(`/api/${V}/highlights`,  apiKeyAuth, highlightsRoutes);
app.use(`/api/${V}/user`,        apiKeyAuth, userRoutes);
app.use(`/api/${V}/search`,      apiKeyAuth, searchRoutes);
app.use(`/api/${V}/hashtag`,     apiKeyAuth, hashtagRoutes);
app.use(`/api/${V}/location`,    apiKeyAuth, locationRoutes);

// ─── Error Handling ───────────────────────────────────────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

// ─── Start ────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  logger.info(`🚀 Instagram API  →  http://localhost:${PORT}/api/${V}`);
  logger.info(`🔑 Auth: ${sessionPool.hasAuth() ? `${sessionPool.count()} sessions` : 'unauthenticated (public only)'}`);
  logger.info(`🌐 Proxies: ${proxyPool.count() > 0 ? proxyPool.count() : 'none (direct)'}`);
  logger.info(`📋 Docs:    http://localhost:${PORT}/api/${V}`);
});

module.exports = app;
