/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       STRATEGY ENGINE — Multi-Fallback Media Fetcher        ║
 * ║  Tries multiple extraction methods in order:                ║
 * ║   1. Instagram Web API (?__a=1)                             ║
 * ║   2. Instagram GraphQL (query hash)                         ║
 * ║   3. Instagram API v1 (mobile endpoint)                     ║
 * ║   4. HTML scrape + JSON-LD                                  ║
 * ║   5. oEmbed (metadata only fallback)                        ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

const { http, jitterDelay } = require('./httpEngine');
const { normalizeMedia, normalizeUserProfile } = require('./normalizer');
const logger = require('../utils/logger');

// ─── Strategy: Web API (__a=1) ────────────────────────────────────────────
async function strategyWebApi(shortcode) {
  const url = `https://www.instagram.com/p/${shortcode}/?__a=1&__d=dis`;
  const res = await http.get(url, {
    axiosOptions: { timeout: 12000 },
    humanDelay: true,
  });

  const body = res.data;
  if (body?.items?.[0]) {
    return normalizeMedia(body.items[0], 'web_api_v1');
  }
  if (body?.graphql?.shortcode_media) {
    return normalizeMedia(body.graphql.shortcode_media, 'web_api_graphql');
  }
  if (body?.data?.shortcode_media) {
    return normalizeMedia(body.data.shortcode_media, 'web_api_data');
  }

  throw new Error('web_api: No media data in response');
}

// ─── Strategy: GraphQL Query ──────────────────────────────────────────────
const GQL_HASHES = {
  media: 'b3055c01b4b222b8a47dc12b090e4e64',       // shortcode media
  mediaAlt: '2b0673e0dc4580674a88d2953fe1a16a',    // alternative hash
};

async function strategyGraphQL(shortcode) {
  await jitterDelay(500, 200); // slight delay to differentiate from web_api attempt

  for (const [name, hash] of Object.entries(GQL_HASHES)) {
    try {
      const variables = JSON.stringify({ shortcode, child_comment_count: 3, fetch_comment_count: 40 });
      const url = `https://www.instagram.com/graphql/query/?query_hash=${hash}&variables=${encodeURIComponent(variables)}`;

      const res = await http.get(url, { axiosOptions: { timeout: 12000 } });
      const media = res.data?.data?.shortcode_media;
      if (media) return normalizeMedia(media, `graphql_${name}`);
    } catch (err) {
      logger.debug(`GraphQL hash ${name} failed: ${err.message}`);
    }
  }
  throw new Error('graphql: All query hashes failed');
}

// ─── Strategy: Mobile API v1 ──────────────────────────────────────────────
async function strategyMobileApi(shortcode) {
  await jitterDelay(800, 300);

  // Convert shortcode to media ID
  const mediaId = shortcodeToId(shortcode);
  const url = `https://www.instagram.com/api/v1/media/${mediaId}/info/`;

  const res = await http.get(url, {
    axiosOptions: { useMobile: true, timeout: 15000 },
  });

  const item = res.data?.items?.[0];
  if (!item) throw new Error('mobile_api: No item in response');

  return normalizeMedia(item, 'mobile_api');
}

// ─── Strategy: HTML Scrape + JSON-LD ─────────────────────────────────────
async function strategyHtmlScrape(shortcode) {
  await jitterDelay(1000, 400);

  const url = `https://www.instagram.com/p/${shortcode}/`;
  const res = await http.get(url, {
    axiosOptions: {
      extraHeaders: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      }
    }
  });

  const html = typeof res.data === 'string' ? res.data : '';
  if (!html) throw new Error('html_scrape: Empty response');

  // Try extracting from window.__additionalDataLoaded
  const additionalMatch = html.match(/window\.__additionalDataLoaded\s*\(\s*'[^']*'\s*,\s*(\{.+?\})\s*\)/s);
  if (additionalMatch) {
    try {
      const data = JSON.parse(additionalMatch[1]);
      const item = data?.items?.[0] || data?.graphql?.shortcode_media;
      if (item) return normalizeMedia(item, 'html_additional_data');
    } catch { /* continue */ }
  }

  // Try extracting from window._sharedData
  const sharedDataMatch = html.match(/window\._sharedData\s*=\s*(\{.+?\});\s*<\/script>/s);
  if (sharedDataMatch) {
    try {
      const data = JSON.parse(sharedDataMatch[1]);
      const media = data?.entry_data?.PostPage?.[0]?.graphql?.shortcode_media;
      if (media) return normalizeMedia(media, 'html_shared_data');
    } catch { /* continue */ }
  }

  // Try JSON-LD schema
  const jsonLdMatches = html.matchAll(/<script type="application\/ld\+json">([^<]+)<\/script>/gs);
  for (const match of jsonLdMatches) {
    try {
      const schema = JSON.parse(match[1]);
      if (schema['@type'] === 'VideoObject' || schema['@type'] === 'ImageObject') {
        return {
          shortcode,
          media_type: schema['@type'] === 'VideoObject' ? 'video' : 'image',
          caption: schema.description || null,
          thumbnail_url: schema.thumbnailUrl,
          video_url: schema.contentUrl || null,
          taken_at: schema.uploadDate ? Math.floor(new Date(schema.uploadDate).getTime() / 1000) : null,
          _source: 'html_jsonld',
          _partial: true, // flag: download URL may be missing
        };
      }
    } catch { /* continue */ }
  }

  throw new Error('html_scrape: No structured data found in page');
}

// ─── Strategy: oEmbed (last resort) ──────────────────────────────────────
async function strategyOEmbed(shortcode) {
  await jitterDelay(500);
  const url = `https://api.instagram.com/oembed/?url=https://www.instagram.com/p/${shortcode}/&format=json&omitscript=true`;

  const res = await http.get(url, { axiosOptions: { useAuth: false } });
  if (!res.data?.title && !res.data?.author_name) {
    throw new Error('oembed: Empty response');
  }

  return {
    shortcode,
    media_type: 'unknown',
    caption: res.data.title || null,
    owner: { username: res.data.author_name, profile_pic_url: res.data.thumbnail_url },
    thumbnail_url: res.data.thumbnail_url,
    _source: 'oembed',
    _partial: true,
  };
}

// ─── Strategy Runner ──────────────────────────────────────────────────────
/**
 * Try all strategies in sequence. First success wins.
 * Errors are collected and surfaced only if ALL strategies fail.
 */
async function fetchWithFallback(shortcode, strategies = null) {
  const allStrategies = strategies || [
    { name: 'web_api',     fn: () => strategyWebApi(shortcode) },
    { name: 'graphql',     fn: () => strategyGraphQL(shortcode) },
    { name: 'mobile_api',  fn: () => strategyMobileApi(shortcode) },
    { name: 'html_scrape', fn: () => strategyHtmlScrape(shortcode) },
    { name: 'oembed',      fn: () => strategyOEmbed(shortcode) },
  ];

  const errors = [];

  for (const strategy of allStrategies) {
    try {
      logger.debug(`Trying strategy: ${strategy.name} for ${shortcode}`);
      const result = await strategy.fn();
      logger.info(`✓ ${strategy.name} succeeded for ${shortcode}`);
      return result;
    } catch (err) {
      // Stop immediately on auth/not-found errors — other strategies won't help
      if ([401, 404].includes(err.status)) {
        logger.warn(`${strategy.name} terminal error (${err.status}): ${err.message}`);
        throw err;
      }
      logger.warn(`${strategy.name} failed: ${err.message}`);
      errors.push({ strategy: strategy.name, error: err.message });
    }
  }

  const errorSummary = errors.map(e => `[${e.strategy}] ${e.error}`).join(' → ');
  const finalError = new Error(
    `All extraction strategies failed for "${shortcode}". ` +
    `The content may be private, deleted, or require authentication. ` +
    `Details: ${errorSummary}`
  );
  finalError.strategies_tried = errors;
  throw finalError;
}

// ─── User Profile Strategies ──────────────────────────────────────────────
async function fetchUserWithFallback(username) {
  const strategies = [
    async () => {
      const url = `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`;
      const res = await http.get(url, { axiosOptions: { extraHeaders: { 'X-IG-App-ID': '936619743392459' } } });
      const user = res.data?.data?.user;
      if (!user) throw new Error('No user in web_profile_info response');
      return normalizeUserProfile(user);
    },
    async () => {
      await jitterDelay(600, 300);
      const url = `https://i.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`;
      const res = await http.get(url, { axiosOptions: { useMobile: true } });
      const user = res.data?.data?.user;
      if (!user) throw new Error('No user in i.instagram response');
      return normalizeUserProfile(user);
    },
    async () => {
      await jitterDelay(800, 400);
      const url = `https://www.instagram.com/${encodeURIComponent(username)}/?__a=1&__d=dis`;
      const res = await http.get(url);
      const user = res.data?.graphql?.user;
      if (!user) throw new Error('No user in __a=1 response');
      return normalizeUserProfile(user);
    },
  ];

  const errors = [];
  for (let i = 0; i < strategies.length; i++) {
    try {
      const result = await strategies[i]();
      return result;
    } catch (err) {
      if (err.status === 404) throw err;
      errors.push(err.message);
      logger.warn(`User strategy ${i + 1}/${strategies.length} failed: ${err.message}`);
    }
  }

  throw new Error(`Could not fetch user @${username}. ${errors[errors.length - 1]}`);
}

// ─── Utilities ────────────────────────────────────────────────────────────

/**
 * Convert Instagram shortcode to numeric media ID
 * (needed for some API v1 endpoints)
 */
function shortcodeToId(shortcode) {
  const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let id = BigInt(0);
  for (const c of shortcode) {
    const charIndex = CHARS.indexOf(c);
    if (charIndex === -1) continue;
    id = id * BigInt(64) + BigInt(charIndex);
  }
  return id.toString();
}

/**
 * Convert numeric media ID to shortcode
 */
function idToShortcode(id) {
  const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let n = BigInt(id);
  let code = '';
  while (n > 0n) {
    const remainder = Number(n % 64n);
    code = CHARS[remainder] + code;
    n = n / 64n;
  }
  return code;
}

module.exports = {
  fetchWithFallback,
  fetchUserWithFallback,
  strategyWebApi,
  strategyGraphQL,
  strategyMobileApi,
  strategyHtmlScrape,
  strategyOEmbed,
  shortcodeToId,
  idToShortcode,
};
