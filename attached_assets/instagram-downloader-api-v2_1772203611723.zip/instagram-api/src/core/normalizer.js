/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         NORMALIZER — Universal Data Transformer             ║
 * ║  Converts any Instagram API response shape into a           ║
 * ║  clean, consistent, well-documented output schema.          ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

// ─── Video Quality Formatter ──────────────────────────────────────────────
function formatVideoDownloads(videoVersions = [], videoUrl = null) {
  const qualityLabels = ['1080p', '720p', '480p', '360p', '240p'];

  // From video_versions array (mobile API format)
  if (videoVersions.length > 0) {
    const sorted = [...videoVersions].sort((a, b) => (b.height || 0) - (a.height || 0));
    return sorted.map((v, i) => ({
      quality: v.height ? `${v.height}p` : (qualityLabels[i] || 'unknown'),
      width: v.width || null,
      height: v.height || null,
      url: v.url,
      type: v.type || null,
    }));
  }

  // Fallback: single video URL
  if (videoUrl) {
    return [{ quality: 'original', width: null, height: null, url: videoUrl, type: null }];
  }

  return [];
}

// ─── Image Quality Formatter ──────────────────────────────────────────────
function formatImageDownloads(imageVersions2 = {}, displayResources = [], displayUrl = null) {
  // Mobile API format
  if (imageVersions2?.candidates?.length) {
    return imageVersions2.candidates
      .map(c => ({ width: c.width, height: c.height, url: c.url }))
      .sort((a, b) => b.width - a.width);
  }

  // GraphQL format
  if (displayResources.length) {
    return displayResources
      .map(r => ({
        width: r.config_width || r.width,
        height: r.config_height || r.height,
        url: r.src || r.url,
      }))
      .sort((a, b) => b.width - a.width);
  }

  // Single URL fallback
  if (displayUrl) return [{ width: null, height: null, url: displayUrl }];

  return [];
}

// ─── Owner/User Normalizer ────────────────────────────────────────────────
function normalizeOwner(raw = {}) {
  if (!raw) return null;
  return {
    id: raw.id || raw.pk || raw.user?.pk || null,
    username: raw.username || raw.user?.username || null,
    full_name: raw.full_name || raw.user?.full_name || null,
    is_verified: raw.is_verified ?? raw.user?.is_verified ?? false,
    is_private: raw.is_private ?? raw.user?.is_private ?? false,
    profile_pic_url: raw.profile_pic_url || raw.user?.profile_pic_url || null,
  };
}

// ─── Caption Normalizer ───────────────────────────────────────────────────
function normalizeCaption(raw) {
  if (!raw) return null;
  // GraphQL format: edge_media_to_caption.edges[0].node.text
  if (raw?.edges?.[0]?.node?.text) return raw.edges[0].node.text;
  // Mobile API format: { text: '...' }
  if (typeof raw === 'object' && raw.text) return raw.text;
  // Plain string
  if (typeof raw === 'string') return raw;
  return null;
}

// ─── Music/Audio Normalizer ───────────────────────────────────────────────
function normalizeMusic(clipsMetadata = {}) {
  const music = clipsMetadata?.music_info?.music_asset_info;
  const originalAudio = clipsMetadata?.original_sound_info;
  const audioType = clipsMetadata?.audio_type;

  if (!music && !originalAudio) return null;

  return {
    type: audioType || (music ? 'licensed_music' : 'original_audio'),
    ...(music && {
      id: music.audio_cluster_id || null,
      title: music.title || null,
      artist: music.artist_display_name || null,
      duration_ms: music.duration_in_ms || null,
      cover_art_url: music.cover_artwork_uri || null,
      audio_download_url: music.progressive_download_url || null,
      is_explicit: music.is_explicit || false,
      spotify_uri: music.spotify_uri || null,
    }),
    ...(originalAudio && !music && {
      id: originalAudio.audio_asset_id || null,
      title: originalAudio.original_media_owner_display_name || 'Original audio',
      artist: null,
      audio_download_url: null,
    }),
  };
}

// ─── Location Normalizer ──────────────────────────────────────────────────
function normalizeLocation(raw) {
  if (!raw) return null;
  return {
    id: raw.id || raw.pk || null,
    name: raw.name || null,
    slug: raw.slug || null,
    lat: raw.lat || null,
    lng: raw.lng || null,
    city: raw.city || null,
  };
}

// ─── Carousel Item Normalizer ─────────────────────────────────────────────
function normalizeCarouselItem(node, index) {
  const isVideo = node.is_video || node.media_type === 2;
  return {
    index: index + 1,
    id: node.id || null,
    shortcode: node.shortcode || node.code || null,
    media_type: isVideo ? 'video' : 'image',
    ...(isVideo
      ? {
          video_downloads: formatVideoDownloads(node.video_versions || [], node.video_url),
          thumbnail_url: node.thumbnail_src || node.display_url || node.image_versions2?.candidates?.[0]?.url || null,
          duration_seconds: node.video_duration || null,
          has_audio: node.has_audio !== undefined ? node.has_audio : true,
        }
      : {
          image_downloads: formatImageDownloads(node.image_versions2, node.display_resources || [], node.display_url),
        }
    ),
    dimensions: node.dimensions || {
      width: node.original_width || null,
      height: node.original_height || null,
    },
    accessibility_caption: node.accessibility_caption || null,
  };
}

// ─── Master Media Normalizer ──────────────────────────────────────────────
/**
 * Normalize any raw Instagram media object into a clean unified shape.
 * Works across all API responses: web, graphql, mobile, scraped HTML.
 */
function normalizeMedia(raw, source = 'unknown') {
  if (!raw) throw new Error('normalizeMedia: raw object is null/undefined');

  // Determine media type robustly
  const typename = raw.__typename || '';
  const mediaTypeCode = raw.media_type; // 1=image, 2=video, 8=carousel
  const isVideo = typename === 'GraphVideo' || mediaTypeCode === 2 || raw.is_video === true;
  const isCarousel = typename === 'GraphSidecar' || mediaTypeCode === 8 || (raw.carousel_media?.length > 0) || (raw.edge_sidecar_to_children?.edges?.length > 0);

  const mediaType = isCarousel ? 'carousel' : isVideo ? 'video' : 'image';
  const shortcode = raw.shortcode || raw.code || null;

  const result = {
    // ── Identity ───────────────────────────────────────────────
    id: raw.id || null,
    shortcode,
    url: shortcode ? `https://www.instagram.com/p/${shortcode}/` : null,
    media_type: mediaType,

    // ── Content ────────────────────────────────────────────────
    caption: normalizeCaption(raw.caption || raw.edge_media_to_caption) || null,
    taken_at: raw.taken_at || raw.taken_at_timestamp || null,
    taken_at_iso: (raw.taken_at || raw.taken_at_timestamp)
      ? new Date((raw.taken_at || raw.taken_at_timestamp) * 1000).toISOString()
      : null,

    // ── Engagement ─────────────────────────────────────────────
    like_count: raw.like_count || raw.edge_media_preview_like?.count || 0,
    comment_count: raw.comment_count || raw.edge_media_to_comment?.count || 0,
    play_count: raw.play_count || raw.video_view_count || null,
    save_count: raw.saved_collection_ids?.length || null,

    // ── Owner ──────────────────────────────────────────────────
    owner: normalizeOwner(raw.owner || raw.user),

    // ── Location ───────────────────────────────────────────────
    location: normalizeLocation(raw.location),

    // ── Meta ───────────────────────────────────────────────────
    accessibility_caption: raw.accessibility_caption || null,
    is_paid_partnership: raw.is_paid_partnership || false,
    product_type: raw.product_type || null, // 'clips', 'igtv', 'feed'

    // ── Source info (for debugging) ────────────────────────────
    _source: source,
  };

  // ── Media-Type Specific Fields ────────────────────────────────
  if (mediaType === 'video') {
    Object.assign(result, {
      video_downloads: formatVideoDownloads(raw.video_versions || [], raw.video_url),
      thumbnail_url: raw.thumbnail_src || raw.thumbnail_url || raw.display_url || raw.image_versions2?.candidates?.[0]?.url || null,
      duration_seconds: raw.video_duration || null,
      has_audio: raw.has_audio !== undefined ? raw.has_audio : true,
      music: normalizeMusic(raw.clips_metadata),
      is_reel: raw.product_type === 'clips' || raw.is_reel === true,
    });
  } else if (mediaType === 'carousel') {
    const edges = raw.edge_sidecar_to_children?.edges?.map(e => e.node) || raw.carousel_media || [];
    Object.assign(result, {
      carousel_count: edges.length,
      carousel_items: edges.map((node, i) => normalizeCarouselItem(node, i)),
      thumbnail_url: raw.display_url || raw.thumbnail_url || null,
    });
  } else {
    Object.assign(result, {
      image_downloads: formatImageDownloads(
        raw.image_versions2,
        raw.display_resources || [],
        raw.display_url
      ),
      thumbnail_url: raw.display_url || raw.image_versions2?.candidates?.[0]?.url || null,
    });
  }

  return result;
}

// ─── User Profile Normalizer ──────────────────────────────────────────────
function normalizeUserProfile(raw) {
  if (!raw) throw new Error('normalizeUserProfile: raw is null');

  return {
    id: raw.id || raw.pk || null,
    username: raw.username || null,
    full_name: raw.full_name || null,
    biography: raw.biography || null,
    bio_links: raw.bio_links?.map(l => ({ url: l.url, title: l.title || null })) || [],
    website: raw.external_url || raw.bio_links?.[0]?.url || null,
    email: raw.public_email || null,
    phone: raw.public_phone_number || null,

    // Profile pictures
    profile_pic_url: raw.profile_pic_url || null,
    profile_pic_url_hd: raw.profile_pic_url_hd || null,

    // Status
    is_verified: raw.is_verified || false,
    is_private: raw.is_private || false,
    is_business: raw.is_business_account || raw.is_business || false,
    is_professional: raw.is_professional_account || false,

    // Category
    business_category: raw.business_category_name || null,
    category: raw.category_name || null,
    account_type: raw.account_type || null,

    // Counts
    follower_count: raw.edge_followed_by?.count ?? raw.follower_count ?? 0,
    following_count: raw.edge_follow?.count ?? raw.following_count ?? 0,
    post_count: raw.edge_owner_to_timeline_media?.count ?? raw.media_count ?? 0,
    highlight_count: raw.highlight_reel_count || 0,

    // Features
    has_reels: raw.has_clips || false,
    has_guides: raw.has_guides || false,
    has_igtv: raw.has_channel || false,

    // Social
    pronouns: raw.pronouns || [],
    related_profiles: (raw.edge_related_profiles?.edges || []).map(e => normalizeOwner(e.node)),

    // Location (business)
    location: raw.city_name
      ? { city: raw.city_name, country: raw.country_block?.country_code || null }
      : null,
  };
}

// ─── Story Item Normalizer ────────────────────────────────────────────────
function normalizeStoryItem(item) {
  const isVideo = item.media_type === 2 || item.is_video;
  return {
    id: item.id || item.pk || null,
    taken_at: item.taken_at || null,
    taken_at_iso: item.taken_at ? new Date(item.taken_at * 1000).toISOString() : null,
    expires_at: item.expiring_at || (item.taken_at ? item.taken_at + 86400 : null),
    media_type: isVideo ? 'video' : 'image',
    ...(isVideo
      ? {
          video_downloads: formatVideoDownloads(item.video_versions || []),
          duration_seconds: item.video_duration || null,
          has_audio: item.has_audio !== undefined ? item.has_audio : true,
        }
      : {
          image_downloads: formatImageDownloads(item.image_versions2 || {}),
        }
    ),
    thumbnail_url: item.image_versions2?.candidates?.[0]?.url || null,
    view_count: item.view_count || null,
    has_liked: item.has_liked || false,
    music: item.music_metadata ? normalizeMusic({ music_info: { music_asset_info: item.music_metadata } }) : null,
  };
}

module.exports = {
  normalizeMedia,
  normalizeUserProfile,
  normalizeOwner,
  normalizeStoryItem,
  normalizeCaption,
  normalizeMusic,
  normalizeLocation,
  normalizeCarouselItem,
  formatVideoDownloads,
  formatImageDownloads,
};
