/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          HTTP ENGINE — Anti-Block Core                       ║
 * ║  • Browser fingerprint rotation                              ║
 * ║  • Exponential backoff + jitter                              ║
 * ║  • Proxy pool rotation                                       ║
 * ║  • Session cookie management                                 ║
 * ║  • Request pacing / human-like delays                        ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

const axios = require('axios');
const logger = require('../utils/logger');

// ─── Browser Fingerprint Pool ────────────────────────────────────────────
const FINGERPRINTS = [
  {
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    sec_ch_ua: '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    sec_ch_ua_platform: '"Windows"',
    sec_ch_ua_mobile: '?0',
  },
  {
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    sec_ch_ua: '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    sec_ch_ua_platform: '"macOS"',
    sec_ch_ua_mobile: '?0',
  },
  {
    ua: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    sec_ch_ua: '"Chromium";v="121", "Not A;Brand";v="99", "Google Chrome";v="121"',
    sec_ch_ua_platform: '"Linux"',
    sec_ch_ua_mobile: '?0',
  },
  {
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
    sec_ch_ua: null, // Firefox doesn't send this
    sec_ch_ua_platform: null,
    sec_ch_ua_mobile: null,
  },
  {
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
    sec_ch_ua: null,
    sec_ch_ua_platform: null,
    sec_ch_ua_mobile: null,
  },
  // Instagram mobile apps (great for API endpoints)
  {
    ua: 'Instagram 269.0.0.18.75 Android (31/12; 420dpi; 1080x2400; samsung; SM-G998B; p3q; exynos2100; en_US; 435574786)',
    sec_ch_ua: null,
    sec_ch_ua_platform: null,
    sec_ch_ua_mobile: null,
    mobile: true,
  },
  {
    ua: 'Instagram 261.0.0.21.111 (iPhone14,2; iOS 16_1; en_US; en-US; scale=3.00; 1170x2532; 401691830) AppleWebKit/420+',
    sec_ch_ua: null,
    sec_ch_ua_platform: null,
    sec_ch_ua_mobile: null,
    mobile: true,
  },
];

// ─── Accept-Language Pool ────────────────────────────────────────────────
const ACCEPT_LANGUAGES = [
  'en-US,en;q=0.9',
  'en-GB,en;q=0.9,en-US;q=0.8',
  'en-US,en;q=0.8,es;q=0.5',
  'en-US,en;q=0.9,fr;q=0.7',
  'en-US,en;q=0.9,de;q=0.7',
];

// ─── Proxy Pool Manager ──────────────────────────────────────────────────
class ProxyPool {
  constructor() {
    this.proxies = this._loadProxies();
    this.currentIndex = 0;
    this.failCounts = new Map();
    this.MAX_FAILS = 3;
  }

  _loadProxies() {
    const proxies = [];

    // Single proxy from env
    if (process.env.PROXY_URL) {
      proxies.push(process.env.PROXY_URL);
    }

    // Multiple proxies from PROXY_POOL (comma-separated)
    if (process.env.PROXY_POOL) {
      const pool = process.env.PROXY_POOL.split(',').map(p => p.trim()).filter(Boolean);
      proxies.push(...pool);
    }

    return [...new Set(proxies)]; // deduplicate
  }

  get() {
    if (!this.proxies.length) return null;

    // Round-robin with failure skipping
    let attempts = 0;
    while (attempts < this.proxies.length) {
      const proxy = this.proxies[this.currentIndex % this.proxies.length];
      this.currentIndex++;
      attempts++;

      const fails = this.failCounts.get(proxy) || 0;
      if (fails < this.MAX_FAILS) return proxy;
    }

    // All proxies failed — reset and try again
    logger.warn('All proxies exceeded fail limit. Resetting counts.');
    this.failCounts.clear();
    return this.proxies[0] || null;
  }

  markFail(proxyUrl) {
    if (!proxyUrl) return;
    const count = (this.failCounts.get(proxyUrl) || 0) + 1;
    this.failCounts.set(proxyUrl, count);
    if (count >= this.MAX_FAILS) {
      logger.warn(`Proxy marked as unhealthy (${count} fails): ${proxyUrl.substring(0, 30)}...`);
    }
  }

  markSuccess(proxyUrl) {
    if (proxyUrl && this.failCounts.has(proxyUrl)) {
      this.failCounts.set(proxyUrl, 0);
    }
  }

  count() { return this.proxies.length; }
}

// ─── Session Pool ────────────────────────────────────────────────────────
class SessionPool {
  constructor() {
    this.sessions = this._loadSessions();
    this.currentIndex = 0;
  }

  _loadSessions() {
    const sessions = [];

    if (process.env.IG_SESSION_ID) {
      sessions.push({
        sessionid: process.env.IG_SESSION_ID,
        csrftoken: process.env.IG_CSRF_TOKEN || '',
        ds_user_id: process.env.IG_DS_USER_ID || '',
        rur: process.env.IG_RUR || '',
      });
    }

    // Support SESSION_POOL as JSON array string
    if (process.env.IG_SESSION_POOL) {
      try {
        const pool = JSON.parse(process.env.IG_SESSION_POOL);
        sessions.push(...pool);
      } catch {
        logger.warn('IG_SESSION_POOL is not valid JSON');
      }
    }

    return sessions;
  }

  get() {
    if (!this.sessions.length) return null;
    const session = this.sessions[this.currentIndex % this.sessions.length];
    this.currentIndex++;
    return session;
  }

  buildCookieString(session) {
    if (!session) return '';
    const parts = [`sessionid=${session.sessionid}`];
    if (session.csrftoken) parts.push(`csrftoken=${session.csrftoken}`);
    if (session.ds_user_id) parts.push(`ds_user_id=${session.ds_user_id}`);
    if (session.rur) parts.push(`rur="${session.rur}"`);
    parts.push('ig_did=; ig_nrcb=1');
    return parts.join('; ');
  }

  count() { return this.sessions.length; }
  hasAuth() { return this.sessions.length > 0; }
}

// ─── Singletons ───────────────────────────────────────────────────────────
const proxyPool = new ProxyPool();
const sessionPool = new SessionPool();

// Log startup info
logger.info(`HTTP Engine: ${proxyPool.count()} proxies | ${sessionPool.count()} sessions loaded`);

// ─── Fingerprint Helper ───────────────────────────────────────────────────
function randomFingerprint(preferMobile = false) {
  const pool = preferMobile
    ? FINGERPRINTS.filter(f => f.mobile)
    : FINGERPRINTS.filter(f => !f.mobile);
  return pool[Math.floor(Math.random() * pool.length)] || FINGERPRINTS[0];
}

function randomAcceptLanguage() {
  return ACCEPT_LANGUAGES[Math.floor(Math.random() * ACCEPT_LANGUAGES.length)];
}

// ─── Jitter Delay ────────────────────────────────────────────────────────
function jitterDelay(baseMs, varianceMs = baseMs * 0.5) {
  const delay = baseMs + (Math.random() - 0.5) * 2 * varianceMs;
  return new Promise(resolve => setTimeout(resolve, Math.max(0, delay)));
}

// ─── Build Headers ────────────────────────────────────────────────────────
function buildHeaders(options = {}) {
  const { useMobile = false, useAuth = true, extra = {} } = options;
  const fp = randomFingerprint(useMobile);
  const session = useAuth ? sessionPool.get() : null;

  const headers = {
    'User-Agent': fp.ua,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': randomAcceptLanguage(),
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Origin': 'https://www.instagram.com',
    'Referer': 'https://www.instagram.com/',
    'X-IG-App-ID': '936619743392459',
    'X-IG-WWW-Claim': '0',
    'X-Requested-With': 'XMLHttpRequest',
    'X-Web-Device-Id': generateDeviceId(),
  };

  if (fp.sec_ch_ua) {
    headers['sec-ch-ua'] = fp.sec_ch_ua;
    headers['sec-ch-ua-mobile'] = fp.sec_ch_ua_mobile;
    headers['sec-ch-ua-platform'] = fp.sec_ch_ua_platform;
    headers['sec-fetch-dest'] = 'empty';
    headers['sec-fetch-mode'] = 'cors';
    headers['sec-fetch-site'] = 'same-origin';
  }

  if (session) {
    headers['Cookie'] = sessionPool.buildCookieString(session);
    if (session.csrftoken) headers['X-CSRFToken'] = session.csrftoken;
  }

  return { ...headers, ...extra };
}

// Generate a stable-ish device ID from env or random
function generateDeviceId() {
  if (!generateDeviceId._cache) {
    const id = process.env.IG_DEVICE_ID ||
      'web_' + Math.random().toString(36).substring(2, 18).toUpperCase();
    generateDeviceId._cache = id;
  }
  return generateDeviceId._cache;
}

// ─── Build Axios Config with Proxy ───────────────────────────────────────
function buildAxiosConfig(options = {}) {
  const { timeout = 20000, useMobile = false, useAuth = true, extraHeaders = {} } = options;

  const config = {
    timeout,
    headers: buildHeaders({ useMobile, useAuth, extra: extraHeaders }),
    maxRedirects: 5,
    validateStatus: status => status < 500, // handle 4xx ourselves
  };

  const proxyUrl = proxyPool.get();
  if (proxyUrl) {
    try {
      const u = new URL(proxyUrl);
      config.proxy = {
        protocol: u.protocol.replace(':', ''),
        host: u.hostname,
        port: parseInt(u.port),
        ...(u.username ? { auth: { username: decodeURIComponent(u.username), password: decodeURIComponent(u.password) } } : {}),
      };
      config._proxyUrl = proxyUrl; // track for fail marking
    } catch {
      logger.warn(`Invalid proxy URL: ${proxyUrl}`);
    }
  }

  return config;
}

// ─── Core Request with Retry ──────────────────────────────────────────────
/**
 * Make a resilient HTTP request with:
 * - Automatic retry on rate-limit / server error
 * - Exponential backoff + jitter
 * - Proxy failure tracking
 * - 429/401/403 smart handling
 */
async function request(method, url, options = {}) {
  const {
    maxRetries = 3,
    baseDelay = 1000,
    data = null,
    params = null,
    axiosOptions = {},
    humanDelay = false,
  } = options;

  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    // Human-like pacing before each request
    if (humanDelay && attempt === 1) {
      await jitterDelay(300, 200);
    }

    const axiosCfg = buildAxiosConfig(axiosOptions);

    try {
      const requestConfig = {
        method,
        url,
        ...axiosCfg,
        ...(params && { params }),
        ...(data && { data }),
      };

      logger.debug(`[${attempt}/${maxRetries}] ${method.toUpperCase()} ${url}`);
      const response = await axios(requestConfig);

      // Track proxy success
      if (axiosCfg._proxyUrl) proxyPool.markSuccess(axiosCfg._proxyUrl);

      // Handle HTTP-level errors
      if (response.status === 429) {
        const retryAfter = parseInt(response.headers['retry-after'] || '60') * 1000;
        logger.warn(`Rate limited (429). Waiting ${retryAfter}ms before retry ${attempt}/${maxRetries}`);
        if (attempt < maxRetries) {
          await jitterDelay(retryAfter, retryAfter * 0.2);
          continue;
        }
        throw Object.assign(new Error('Instagram rate limit exceeded. Please slow down your requests.'), { status: 429 });
      }

      if (response.status === 401) {
        throw Object.assign(new Error('Instagram authentication required. Add IG_SESSION_ID to .env'), { status: 401 });
      }

      if (response.status === 403) {
        // Could be CSRF or block — retry with fresh fingerprint
        if (attempt < maxRetries) {
          logger.warn(`403 on attempt ${attempt} — rotating fingerprint and retrying...`);
          await jitterDelay(baseDelay * attempt * 2);
          continue;
        }
        throw Object.assign(new Error('Access forbidden. Try adding or rotating session credentials.'), { status: 403 });
      }

      if (response.status === 404) {
        throw Object.assign(new Error('Content not found. It may be private, deleted, or the URL is incorrect.'), { status: 404 });
      }

      if (response.status >= 500) {
        if (attempt < maxRetries) {
          await jitterDelay(baseDelay * attempt, baseDelay * 0.5);
          continue;
        }
        throw Object.assign(new Error(`Instagram server error (${response.status}). Try again later.`), { status: response.status });
      }

      // Check for Instagram's "checkpoint" / login wall in JSON
      if (response.data?.message === 'login_required' || response.data?.require_login) {
        throw Object.assign(new Error('Login required for this content. Add IG_SESSION_ID to .env'), { status: 401 });
      }

      return response;

    } catch (err) {
      // Mark proxy fail on network errors
      if (axiosCfg._proxyUrl && err.code && ['ECONNREFUSED', 'ETIMEDOUT', 'ECONNRESET', 'ERR_BAD_RESPONSE'].includes(err.code)) {
        proxyPool.markFail(axiosCfg._proxyUrl);
      }

      lastError = err;

      // Don't retry on definitive errors
      if ([401, 404].includes(err.status)) throw err;

      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt - 1);
        logger.warn(`Request failed (attempt ${attempt}/${maxRetries}): ${err.message}. Retrying in ${delay}ms...`);
        await jitterDelay(delay, delay * 0.3);
      }
    }
  }

  throw lastError || new Error('Request failed after max retries');
}

// Convenience methods
const http = {
  get: (url, options = {}) => request('GET', url, options),
  post: (url, data, options = {}) => request('POST', url, { ...options, data }),
};

module.exports = {
  http,
  request,
  proxyPool,
  sessionPool,
  buildHeaders,
  jitterDelay,
  FINGERPRINTS,
};
