const express = require('express');
const router = express.Router();
const { query, validationResult } = require('express-validator');
const { getOrSet } = require('../utils/cache');
const ig = require('../services/instagram');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

router.get('/', [
  query('q').notEmpty().withMessage('Search query required'),
  query('type').optional().isIn(['blended', 'user', 'hashtag', 'place'])
], validate, async (req, res, next) => {
  try {
    const { q, type = 'blended' } = req.query;
    const { data, fromCache } = await getOrSet(`search:${type}:${q}`, () =>
      ig.search(q, type), 120
    );
    res.json({ success: true, from_cache: fromCache, ...data });
  } catch (err) { next(err); }
});

module.exports = router;
