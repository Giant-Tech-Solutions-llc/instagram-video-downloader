const express = require('express');
const router = express.Router();
const { query, validationResult } = require('express-validator');
const { getOrSet } = require('../utils/cache');
const ig = require('../services/instagram');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

router.get('/', [
  query('username').notEmpty().withMessage('Username required')
], validate, async (req, res, next) => {
  try {
    const { username } = req.query;
    const { data, fromCache } = await getOrSet(`highlights:${username}`, () =>
      ig.fetchUserHighlights(username), 600
    );
    res.json({ success: true, from_cache: fromCache, username, ...data });
  } catch (err) { next(err); }
});

router.get('/items', [
  query('id').notEmpty().withMessage('Highlight ID required')
], validate, async (req, res, next) => {
  try {
    const { id } = req.query;
    const { data, fromCache } = await getOrSet(`highlight:items:${id}`, () =>
      ig.fetchHighlightItems(id), 300
    );
    res.json({ success: true, from_cache: fromCache, ...data });
  } catch (err) { next(err); }
});

module.exports = router;
