const express = require('express');
const router = express.Router();
const { query, validationResult } = require('express-validator');
const { getOrSet } = require('../utils/cache');
const ig = require('../services/instagram');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

/**
 * GET /api/v1/media
 * Universal downloader — pass any Instagram URL
 * Returns fully normalized media with all download URLs at all quality levels
 */
router.get('/', [
  query('url').isURL().withMessage('A valid Instagram URL is required'),
  query('quality').optional().isIn(['best', '1080p', '720p', '480p', '360p']).withMessage('quality must be: best, 1080p, 720p, 480p, 360p'),
], validate, async (req, res, next) => {
  try {
    const { url, quality = 'best' } = req.query;
    const shortcode = ig.extractShortcode(url);
    const type = ig.detectMediaType(url);

    const { data, fromCache } = await getOrSet(`media:${shortcode}`, () => ig.fetchMedia(url));

    // If quality filtering requested for single video
    if (data.media_type === 'video' && quality !== 'best' && data.video_downloads?.length) {
      const preferred = data.video_downloads.find(v => v.quality === quality) || data.video_downloads[0];
      data._selected_download = preferred;
    } else if (data.media_type === 'video') {
      data._selected_download = data.video_downloads?.[0] || null;
    }

    res.json({
      success: true,
      cached: fromCache,
      detected_type: type,
      shortcode,
      data,
    });
  } catch (err) { next(err); }
});

/**
 * POST /api/v1/media/batch
 * Download multiple URLs at once (max 10)
 * Body: { urls: ['url1', 'url2', ...] }
 */
router.post('/batch', async (req, res, next) => {
  try {
    const { urls } = req.body;
    if (!Array.isArray(urls) || !urls.length) {
      return res.status(400).json({ success: false, error: 'Body must contain a "urls" array' });
    }
    if (urls.length > 10) {
      return res.status(400).json({ success: false, error: 'Maximum 10 URLs per batch request' });
    }

    const results = await Promise.allSettled(
      urls.map(async (url) => {
        const shortcode = ig.extractShortcode(url);
        const { data } = await getOrSet(`media:${shortcode}`, () => ig.fetchMedia(url));
        return data;
      })
    );

    const response = results.map((r, i) => ({
      url: urls[i],
      success: r.status === 'fulfilled',
      data: r.status === 'fulfilled' ? r.value : null,
      error: r.status === 'rejected' ? r.reason?.message : null,
    }));

    res.json({
      success: true,
      total: urls.length,
      succeeded: response.filter(r => r.success).length,
      failed: response.filter(r => !r.success).length,
      results: response,
    });
  } catch (err) { next(err); }
});

/**
 * GET /api/v1/media/likers?shortcode=ABC123
 */
router.get('/likers', [
  query('shortcode').notEmpty().withMessage('shortcode is required'),
], validate, async (req, res, next) => {
  try {
    const { shortcode } = req.query;
    const { data, fromCache } = await getOrSet(`likers:${shortcode}`, () =>
      ig.fetchMediaLikers(shortcode), 60
    );
    res.json({ success: true, cached: fromCache, ...data });
  } catch (err) { next(err); }
});

/**
 * GET /api/v1/media/comments?shortcode=ABC123&cursor=...
 */
router.get('/comments', [
  query('shortcode').notEmpty().withMessage('shortcode is required'),
  query('cursor').optional(),
], validate, async (req, res, next) => {
  try {
    const { shortcode, cursor } = req.query;
    const data = await ig.fetchMediaComments(shortcode, cursor);
    res.json({ success: true, ...data });
  } catch (err) { next(err); }
});

/**
 * GET /api/v1/media/audio?url=...
 * Extract music/audio info from a reel
 */
router.get('/audio', [
  query('url').isURL().withMessage('A valid Instagram URL is required'),
], validate, async (req, res, next) => {
  try {
    const { url } = req.query;
    const shortcode = ig.extractShortcode(url);
    const { data, fromCache } = await getOrSet(`audio:${shortcode}`, () =>
      ig.fetchReelAudio(url)
    );
    res.json({ success: true, cached: fromCache, ...data });
  } catch (err) { next(err); }
});

module.exports = router;
