// ─── Stories Route ────────────────────────────────────────────────────────
const express = require('express');
const { query, validationResult } = require('express-validator');
const { getOrSet } = require('../utils/cache');
const ig = require('../services/instagram');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

const storiesRouter = express.Router();

/**
 * GET /api/v1/stories
 * Get user's active stories
 */
storiesRouter.get('/', [
  query('username').notEmpty().withMessage('Username required')
], validate, async (req, res, next) => {
  try {
    const { username } = req.query;
    const { data, fromCache } = await getOrSet(`stories:${username}`, () =>
      ig.fetchUserStories(username), 60
    );

    res.json({ success: true, from_cache: fromCache, username, ...data });
  } catch (err) {
    next(err);
  }
});

// ─── Highlights Route ─────────────────────────────────────────────────────
const highlightsRouter = express.Router();

/**
 * GET /api/v1/highlights
 * Get user's highlight covers
 */
highlightsRouter.get('/', [
  query('username').notEmpty().withMessage('Username required')
], validate, async (req, res, next) => {
  try {
    const { username } = req.query;
    const { data, fromCache } = await getOrSet(`highlights:${username}`, () =>
      ig.fetchUserHighlights(username), 600
    );

    res.json({ success: true, from_cache: fromCache, username, ...data });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/v1/highlights/items
 * Get items inside a specific highlight
 */
highlightsRouter.get('/items', [
  query('id').notEmpty().withMessage('Highlight ID required')
], validate, async (req, res, next) => {
  try {
    const { id } = req.query;
    const { data, fromCache } = await getOrSet(`highlight:items:${id}`, () =>
      ig.fetchHighlightItems(id), 300
    );

    res.json({ success: true, from_cache: fromCache, ...data });
  } catch (err) {
    next(err);
  }
});

// ─── Search Route ─────────────────────────────────────────────────────────
const searchRouter = express.Router();

/**
 * GET /api/v1/search
 * Search users, hashtags, places
 */
searchRouter.get('/', [
  query('q').notEmpty().withMessage('Search query required'),
  query('type').optional().isIn(['blended', 'user', 'hashtag', 'place'])
], validate, async (req, res, next) => {
  try {
    const { q, type = 'blended' } = req.query;
    const { data, fromCache } = await getOrSet(`search:${type}:${q}`, () =>
      ig.search(q, type), 120
    );

    res.json({ success: true, from_cache: fromCache, ...data });
  } catch (err) {
    next(err);
  }
});

// ─── Hashtag Route ────────────────────────────────────────────────────────
const hashtagRouter = express.Router();

/**
 * GET /api/v1/hashtag
 * Get top posts for a hashtag
 */
hashtagRouter.get('/', [
  query('tag').notEmpty().withMessage('Hashtag required'),
  query('cursor').optional()
], validate, async (req, res, next) => {
  try {
    const { tag, cursor } = req.query;
    const cleanTag = tag.replace('#', '');
    const { data, fromCache } = await getOrSet(`hashtag:${cleanTag}:${cursor || 'start'}`, () =>
      ig.fetchHashtagPosts(cleanTag, cursor), 180
    );

    res.json({ success: true, from_cache: fromCache, ...data });
  } catch (err) {
    next(err);
  }
});

module.exports = {
  storiesRouter,
  highlightsRouter,
  searchRouter,
  hashtagRouter,
};
