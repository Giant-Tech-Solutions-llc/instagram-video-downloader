const express = require('express');
const router = express.Router();
const { query, validationResult } = require('express-validator');
const { getOrSet } = require('../utils/cache');
const ig = require('../services/instagram');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

/**
 * GET /api/v1/reels
 * Download a single reel by URL
 */
router.get('/', [
  query('url').isURL().withMessage('Valid Instagram reel URL required'),
  query('quality').optional().isIn(['best', '1080p', '720p', '480p', '360p'])
], validate, async (req, res, next) => {
  try {
    const { url, quality = 'best' } = req.query;
    const shortcode = ig.extractShortcode(url);

    const { data: raw, fromCache } = await getOrSet(`reel:${shortcode}`, () =>
      ig.fetchMediaByShortcode(shortcode)
    );

    const videos = ig.formatVideoOptions(raw.video_versions || []);
    const selected = quality === 'best' ? videos[0] : (videos.find(v => v.quality === quality) || videos[0]);

    res.json({
      success: true,
      from_cache: fromCache,
      shortcode,
      reel_url: `https://www.instagram.com/reel/${shortcode}/`,
      caption: raw.caption || null,
      taken_at: raw.taken_at,
      like_count: raw.like_count || 0,
      comment_count: raw.comment_count || 0,
      play_count: raw.play_count || null,
      duration: raw.video_duration || null,
      has_audio: raw.has_audio !== undefined ? raw.has_audio : true,
      owner: raw.owner || raw.user,
      download: {
        selected_quality: selected || null,
        all_qualities: videos,
        thumbnail: raw.thumbnail_url || (raw.image_versions2?.candidates?.[0]?.url),
      },
      music: raw.clips_metadata?.music_info
        ? {
            title: raw.clips_metadata.music_info.music_asset_info?.title,
            artist: raw.clips_metadata.music_info.music_asset_info?.artist_display_name,
            audio_url: raw.clips_metadata.music_info.music_asset_info?.progressive_download_url,
          }
        : null,
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/v1/reels/user
 * Get all reels for a user
 */
router.get('/user', [
  query('username').notEmpty().withMessage('Username required'),
  query('cursor').optional()
], validate, async (req, res, next) => {
  try {
    const { username, cursor } = req.query;
    const { data, fromCache } = await getOrSet(`reels:user:${username}:${cursor || 'start'}`, () =>
      ig.fetchUserReels(username, cursor)
    );

    res.json({ success: true, from_cache: fromCache, username, ...data });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/v1/reels/explore
 * Get explore/trending reels
 */
router.get('/explore', [
  query('cursor').optional()
], validate, async (req, res, next) => {
  try {
    const { cursor } = req.query;
    const { data, fromCache } = await getOrSet(`reels:explore:${cursor || 'start'}`, () =>
      ig.fetchExploreReels(cursor), 120
    );

    res.json({ success: true, from_cache: fromCache, ...data });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
