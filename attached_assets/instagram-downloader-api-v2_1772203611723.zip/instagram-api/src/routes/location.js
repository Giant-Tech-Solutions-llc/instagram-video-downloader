const express = require('express');
const router = express.Router();
const { query, validationResult } = require('express-validator');
const { getOrSet } = require('../utils/cache');
const ig = require('../services/instagram');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

/**
 * GET /api/v1/location?id=123456789
 * Get posts for a location
 */
router.get('/', [
  query('id').notEmpty().withMessage('Location ID required'),
  query('cursor').optional(),
], validate, async (req, res, next) => {
  try {
    const { id, cursor } = req.query;
    const { data, fromCache } = await getOrSet(`location:${id}:${cursor || 'start'}`, () =>
      ig.fetchLocationPosts(id, cursor), 300
    );
    res.json({ success: true, cached: fromCache, ...data });
  } catch (err) { next(err); }
});

module.exports = router;
