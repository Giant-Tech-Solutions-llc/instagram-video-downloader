/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       INSTAGRAM SERVICE — Public API                        ║
 * ║  Clean orchestration layer. Routes calls through the        ║
 * ║  strategy engine and normalizer.                            ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

const { http, jitterDelay } = require('../core/httpEngine');
const { fetchWithFallback, fetchUserWithFallback, shortcodeToId } = require('../core/strategies');
const { normalizeMedia, normalizeUserProfile, normalizeStoryItem, normalizeOwner } = require('../core/normalizer');
const logger = require('../utils/logger');

// ─── URL Utilities ────────────────────────────────────────────────────────

const URL_PATTERNS = [
  { pattern: /instagram\.com\/p\/([A-Za-z0-9_-]+)/, type: 'post' },
  { pattern: /instagram\.com\/reel(?:s)?\/([A-Za-z0-9_-]+)/, type: 'reel' },
  { pattern: /instagram\.com\/tv\/([A-Za-z0-9_-]+)/, type: 'igtv' },
  { pattern: /instagram\.com\/stories\/[^/]+\/(\d+)/, type: 'story' },
];

function extractShortcode(url) {
  const cleanUrl = url.split('?')[0].replace(/\/$/, '');
  for (const { pattern } of URL_PATTERNS) {
    const match = cleanUrl.match(pattern);
    if (match) return match[1];
  }
  throw Object.assign(
    new Error(`Cannot parse Instagram URL: "${url}". Supported: /p/, /reel/, /reels/, /tv/`),
    { status: 400 }
  );
}

function detectMediaType(url) {
  for (const { pattern, type } of URL_PATTERNS) {
    if (pattern.test(url)) return type;
  }
  return 'unknown';
}

// ─── Media ────────────────────────────────────────────────────────────────

async function fetchMedia(urlOrShortcode) {
  const shortcode = urlOrShortcode.includes('instagram.com')
    ? extractShortcode(urlOrShortcode)
    : urlOrShortcode;
  return fetchWithFallback(shortcode);
}

// ─── User ─────────────────────────────────────────────────────────────────

async function fetchUserInfo(username) {
  const clean = username.replace(/^@/, '').toLowerCase().trim();
  return fetchUserWithFallback(clean);
}

async function fetchUserPosts(username, cursor = null) {
  const user = await fetchUserInfo(username);
  const vars = JSON.stringify({ id: user.id, first: 12, after: cursor || null });
  const url = `https://www.instagram.com/graphql/query/?query_hash=e769aa130647d2354c40ea6a439bfc08&variables=${encodeURIComponent(vars)}`;

  const res = await http.get(url, { humanDelay: true });
  const timeline = res.data?.data?.user?.edge_owner_to_timeline_media;
  if (!timeline) throw new Error('Could not fetch posts. User may be private.');

  return {
    user: { id: user.id, username: user.username },
    posts: (timeline.edges || []).map(e => _normalizePostEdge(e.node)),
    pagination: {
      has_next_page: timeline.page_info?.has_next_page || false,
      next_cursor: timeline.page_info?.end_cursor || null,
      total_count: timeline.count || null,
    },
  };
}

function _normalizePostEdge(node) {
  if (!node) return null;
  const isVideo = node.is_video;
  const isCarousel = node.__typename === 'GraphSidecar';
  return {
    id: node.id,
    shortcode: node.shortcode,
    url: `https://www.instagram.com/p/${node.shortcode}/`,
    media_type: isCarousel ? 'carousel' : isVideo ? 'video' : 'image',
    thumbnail_url: node.thumbnail_src || node.display_url || null,
    taken_at: node.taken_at_timestamp || null,
    taken_at_iso: node.taken_at_timestamp ? new Date(node.taken_at_timestamp * 1000).toISOString() : null,
    like_count: node.edge_media_preview_like?.count || 0,
    comment_count: node.edge_media_to_comment?.count || 0,
    caption: node.edge_media_to_caption?.edges?.[0]?.node?.text?.substring(0, 300) || null,
    play_count: node.video_view_count || null,
  };
}

// ─── Stories ──────────────────────────────────────────────────────────────

async function fetchUserStories(username) {
  const user = await fetchUserInfo(username);
  const res = await http.get(
    `https://www.instagram.com/api/v1/feed/reels_media/?reel_ids=${user.id}`,
    { humanDelay: true }
  );
  const reel = res.data?.reels_media?.[0];
  if (!reel?.items?.length) {
    return { user: { id: user.id, username: user.username }, stories: [], count: 0,
      note: 'No active stories or authentication required.' };
  }
  return {
    user: { id: user.id, username: user.username },
    stories: reel.items.map(item => normalizeStoryItem(item)),
    count: reel.items.length,
  };
}

// ─── Highlights ───────────────────────────────────────────────────────────

async function fetchUserHighlights(username) {
  const user = await fetchUserInfo(username);
  const res = await http.get(
    `https://www.instagram.com/api/v1/highlights/${user.id}/highlights_tray/`,
    { humanDelay: true }
  );
  const tray = res.data?.tray;
  if (!tray) throw new Error('No highlights found. Authentication may be required.');
  return {
    user: { id: user.id, username: user.username },
    highlights: tray.map(h => ({
      id: h.id.replace('highlight:', ''),
      full_id: h.id,
      title: h.title,
      cover_image: h.cover_media_cropped_thumbnail?.url || h.cover_media?.cropped_image_version?.url || null,
      item_count: h.media_count || null,
      created_at: h.created_at || null,
    })),
    count: tray.length,
  };
}

async function fetchHighlightItems(highlightId) {
  const fullId = highlightId.startsWith('highlight:') ? highlightId : `highlight:${highlightId}`;
  const res = await http.get(
    `https://www.instagram.com/api/v1/feed/reels_media/?reel_ids=${fullId}`,
    { humanDelay: true }
  );
  const reel = res.data?.reels_media?.[0];
  if (!reel) throw new Error('Highlight not found or authentication required.');
  return {
    id: highlightId,
    title: reel.title || null,
    user: normalizeOwner(reel.user),
    items: (reel.items || []).map(item => normalizeStoryItem(item)),
    count: reel.items?.length || 0,
  };
}

// ─── Reels ────────────────────────────────────────────────────────────────

async function fetchUserReels(username, cursor = null) {
  const user = await fetchUserInfo(username);
  const res = await http.get(
    `https://www.instagram.com/api/v1/clips/user/?target_user_id=${user.id}&page_size=12${cursor ? `&max_id=${cursor}` : ''}`,
    { humanDelay: true }
  );
  return {
    user: { id: user.id, username: user.username },
    reels: (res.data?.items || []).map(item => _normalizeReelItem(item.media || item)),
    pagination: {
      has_more: res.data?.paging_info?.more_available || false,
      next_cursor: res.data?.paging_info?.max_id || null,
    },
  };
}

async function fetchExploreReels(cursor = null) {
  const res = await http.get(
    `https://www.instagram.com/api/v1/clips/explore/?${cursor ? `max_id=${cursor}` : ''}`,
    { humanDelay: true }
  );
  return {
    reels: (res.data?.items || []).map(item => _normalizeReelItem(item.media || item)),
    pagination: {
      has_more: res.data?.paging_info?.more_available || false,
      next_cursor: res.data?.paging_info?.max_id || null,
    },
  };
}

function _normalizeReelItem(m) {
  return {
    id: m.id || null,
    shortcode: m.code || m.shortcode || null,
    url: m.code ? `https://www.instagram.com/reel/${m.code}/` : null,
    taken_at: m.taken_at || null,
    taken_at_iso: m.taken_at ? new Date(m.taken_at * 1000).toISOString() : null,
    caption: (typeof m.caption === 'object' ? m.caption?.text : m.caption || '').substring(0, 300),
    like_count: m.like_count || 0,
    comment_count: m.comment_count || 0,
    play_count: m.play_count || m.view_count || null,
    duration_seconds: m.video_duration || null,
    thumbnail_url: m.image_versions2?.candidates?.[0]?.url || null,
    has_audio: m.has_audio !== undefined ? m.has_audio : true,
    owner: normalizeOwner(m.user || m.owner),
  };
}

// ─── Media Likers ─────────────────────────────────────────────────────────

async function fetchMediaLikers(shortcode) {
  const mediaId = shortcodeToId(shortcode);
  const res = await http.get(
    `https://www.instagram.com/api/v1/media/${mediaId}/likers/`,
    { humanDelay: true }
  );
  return {
    shortcode, media_id: mediaId,
    likers: (res.data?.users || []).map(u => normalizeOwner(u)),
    count: res.data?.user_count || res.data?.users?.length || 0,
  };
}

// ─── Media Comments ───────────────────────────────────────────────────────

async function fetchMediaComments(shortcode, cursor = null) {
  const mediaId = shortcodeToId(shortcode);
  const res = await http.get(
    `https://www.instagram.com/api/v1/media/${mediaId}/comments/?can_support_threading=true${cursor ? `&min_id=${cursor}` : ''}`,
    { humanDelay: true }
  );
  return {
    shortcode,
    comments: (res.data?.comments || []).map(c => ({
      id: c.pk || c.id || null,
      text: c.text || null,
      created_at: c.created_at || null,
      created_at_iso: c.created_at ? new Date(c.created_at * 1000).toISOString() : null,
      like_count: c.comment_like_count || 0,
      user: normalizeOwner(c.user),
      reply_count: c.child_comment_count || 0,
    })),
    pagination: {
      has_more: res.data?.has_more_comments || false,
      next_cursor: res.data?.next_min_id || null,
    },
  };
}

// ─── Followers / Following ────────────────────────────────────────────────

async function fetchFollowers(username, cursor = null) {
  const user = await fetchUserInfo(username);
  const res = await http.get(
    `https://www.instagram.com/api/v1/friendships/${user.id}/followers/?count=50${cursor ? `&max_id=${cursor}` : ''}`,
    { humanDelay: true }
  );
  return {
    user: { id: user.id, username: user.username },
    followers: (res.data?.users || []).map(u => normalizeOwner(u)),
    pagination: { has_more: !!res.data?.next_max_id, next_cursor: res.data?.next_max_id || null },
  };
}

async function fetchFollowings(username, cursor = null) {
  const user = await fetchUserInfo(username);
  const res = await http.get(
    `https://www.instagram.com/api/v1/friendships/${user.id}/following/?count=50${cursor ? `&max_id=${cursor}` : ''}`,
    { humanDelay: true }
  );
  return {
    user: { id: user.id, username: user.username },
    followings: (res.data?.users || []).map(u => normalizeOwner(u)),
    pagination: { has_more: !!res.data?.next_max_id, next_cursor: res.data?.next_max_id || null },
  };
}

// ─── Search ───────────────────────────────────────────────────────────────

async function search(query, type = 'blended') {
  const res = await http.get(
    `https://www.instagram.com/api/v1/web/search/topsearch/?query=${encodeURIComponent(query)}&context=${type}`,
    { humanDelay: true }
  );
  return {
    query, type,
    users: (res.data?.users || []).map(u => ({
      rank: u.position,
      follower_count: u.user?.follower_count || 0,
      ...normalizeOwner(u.user),
      mutual_followers_text: u.user?.social_context || null,
    })),
    hashtags: (res.data?.hashtags || []).map(h => ({
      rank: h.position, name: h.hashtag?.name || null,
      media_count: h.hashtag?.media_count || 0, id: h.hashtag?.id || null,
    })),
    places: (res.data?.places || []).map(p => ({
      rank: p.position, title: p.place?.title || null,
      subtitle: p.place?.subtitle || null,
      lat: p.place?.location?.lat || null, lng: p.place?.location?.lng || null,
    })),
  };
}

// ─── Hashtag ──────────────────────────────────────────────────────────────

async function fetchHashtagPosts(tag, cursor = null) {
  const cleanTag = tag.replace(/^#/, '');
  const [infoRes, postsRes] = await Promise.allSettled([
    http.get(`https://www.instagram.com/api/v1/tags/web_info/?tag_name=${encodeURIComponent(cleanTag)}`),
    http.post(`https://www.instagram.com/api/v1/tags/${encodeURIComponent(cleanTag)}/sections/`,
      { tab: 'top', page: 1, ...(cursor ? { next_media_ids: [cursor] } : {}) }),
  ]);
  const tagData = infoRes.status === 'fulfilled' ? infoRes.value.data?.data : null;
  const postsData = postsRes.status === 'fulfilled' ? postsRes.value.data : null;
  const medias = [];
  for (const section of postsData?.sections || []) {
    for (const layout of section.layout_content?.medias || []) {
      const m = _normalizePostEdge(layout.media);
      if (m) medias.push(m);
    }
  }
  return {
    tag: cleanTag,
    info: tagData?.hashtag ? {
      id: tagData.hashtag.id, name: tagData.hashtag.name,
      media_count: tagData.hashtag.media_count,
      is_trending: tagData.hashtag.is_trending_in_media || false,
    } : null,
    posts: medias,
    pagination: { has_more: postsData?.more_available || false, next_cursor: postsData?.next_max_id || null },
  };
}

// ─── Location ─────────────────────────────────────────────────────────────

async function fetchLocationPosts(locationId, cursor = null) {
  const res = await http.get(
    `https://www.instagram.com/explore/locations/${locationId}/?__a=1&__d=dis`,
    { humanDelay: true }
  );
  const location = res.data?.native_location_data || res.data?.graphql?.location;
  if (!location) throw new Error('Location not found.');
  const edges = location.edge_location_to_media?.edges || [];
  return {
    location: {
      id: location.id || locationId, name: location.name || null,
      slug: location.slug || null, lat: location.lat || null, lng: location.lng || null,
      city: location.city || null, website: location.website || null,
    },
    posts: edges.map(e => _normalizePostEdge(e.node)).filter(Boolean),
    pagination: {
      has_more: location.edge_location_to_media?.page_info?.has_next_page || false,
      next_cursor: location.edge_location_to_media?.page_info?.end_cursor || null,
    },
  };
}

// ─── Audio ────────────────────────────────────────────────────────────────

async function fetchReelAudio(urlOrShortcode) {
  const media = await fetchMedia(urlOrShortcode);
  return {
    shortcode: media.shortcode,
    media_url: media.url,
    has_audio: media.has_audio,
    original_video_url: media.video_downloads?.[0]?.url || null,
    music: media.music || null,
  };
}

module.exports = {
  extractShortcode, detectMediaType,
  fetchMedia, fetchUserInfo, fetchUserPosts,
  fetchUserStories, fetchUserHighlights, fetchHighlightItems,
  fetchUserReels, fetchExploreReels,
  fetchMediaLikers, fetchMediaComments,
  fetchFollowers, fetchFollowings,
  search, fetchHashtagPosts, fetchLocationPosts,
  fetchReelAudio,
};
