const logger = require('../utils/logger');

function errorHandler(err, req, res, next) {
  logger.error(`Error [${req.requestId}]: ${err.message}`, { stack: err.stack });

  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  // Instagram-specific errors
  let userMessage = message;
  if (message.includes('401') || message.includes('Unauthorized')) {
    userMessage = 'Instagram authentication required. Please configure IG_SESSION_ID in your .env file.';
  } else if (message.includes('404') || message.includes('not found')) {
    userMessage = 'Content not found. It may be private, deleted, or the URL is invalid.';
  } else if (message.includes('429') || message.includes('rate')) {
    userMessage = 'Instagram rate limit hit. Please wait before making more requests.';
  } else if (message.includes('private')) {
    userMessage = 'This account is private. Authentication with a following account required.';
  }

  res.status(status).json({
    success: false,
    error: userMessage,
    request_id: req.requestId,
    timestamp: new Date().toISOString(),
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
}

function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    error: `Route not found: ${req.method} ${req.originalUrl}`,
    hint: 'Check /api/v1 for available endpoints'
  });
}

module.exports = { errorHandler, notFoundHandler };
