const logger = require('../utils/logger');

/**
 * API Key Authentication Middleware
 * Accepts key via: x-api-key header OR ?api_key query param OR Bearer token
 */
function apiKeyAuth(req, res, next) {
  // Development mode: skip auth if no key is configured
  if (process.env.NODE_ENV === 'development' && !process.env.API_KEY_SECRET) {
    return next();
  }

  const apiKey =
    req.headers['x-api-key'] ||
    req.query.api_key ||
    (req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.slice(7)
      : null);

  if (!apiKey) {
    return res.status(401).json({
      success: false,
      error: 'API key required. Pass via x-api-key header, Authorization: Bearer <key>, or ?api_key= query param.'
    });
  }

  if (apiKey !== process.env.API_KEY_SECRET) {
    logger.warn(`Invalid API key attempt from ${req.ip} | Request ID: ${req.requestId}`);
    return res.status(403).json({
      success: false,
      error: 'Invalid API key.'
    });
  }

  next();
}

module.exports = { apiKeyAuth };
