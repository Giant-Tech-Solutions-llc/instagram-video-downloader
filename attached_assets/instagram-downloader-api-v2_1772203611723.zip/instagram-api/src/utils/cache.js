const NodeCache = require('node-cache');
const logger = require('./logger');

const cache = new NodeCache({
  stdTTL: parseInt(process.env.CACHE_TTL) || 300,
  checkperiod: 60,
  useClones: false
});

cache.on('set', (key) => logger.debug(`Cache SET: ${key}`));
cache.on('del', (key) => logger.debug(`Cache DEL: ${key}`));
cache.on('expired', (key) => logger.debug(`Cache EXPIRED: ${key}`));

/**
 * Get or set cache value
 * @param {string} key
 * @param {Function} fetchFn - async function to fetch data if not cached
 * @param {number} ttl - optional custom TTL
 */
async function getOrSet(key, fetchFn, ttl = null) {
  const cached = cache.get(key);
  if (cached !== undefined) {
    logger.debug(`Cache HIT: ${key}`);
    return { data: cached, fromCache: true };
  }

  logger.debug(`Cache MISS: ${key}`);
  const data = await fetchFn();
  cache.set(key, data, ttl || parseInt(process.env.CACHE_TTL) || 300);
  return { data, fromCache: false };
}

function invalidate(key) {
  cache.del(key);
}

function flush() {
  cache.flushAll();
}

function stats() {
  return cache.getStats();
}

module.exports = { cache, getOrSet, invalidate, flush, stats };
