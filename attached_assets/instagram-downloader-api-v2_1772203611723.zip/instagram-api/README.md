# 📸 Instagram Downloader API v2

> Production-grade Instagram scraper API. Built to be more reliable, more complete, and far easier to use than anything on RapidAPI.

---

## 🚀 Quick Start

```bash
npm install
cp .env.example .env          # configure your API key
npm start
```

Visit `http://localhost:3000/api/v1` for live endpoint documentation.

---

## ⚙️ Configuration

```env
PORT=3000
API_KEY_SECRET=your_strong_random_key_here

# Optional but recommended — unlocks stories, followers, followings
IG_SESSION_ID=your_instagram_session_id
IG_CSRF_TOKEN=your_csrf_token

# Proxy pool — use in production to avoid IP blocks
PROXY_POOL=http://user:pass@proxy1:8080,http://user:pass@proxy2:8080

# Multiple sessions for rotation
IG_SESSION_POOL=[{"sessionid":"abc","csrftoken":"xyz"},{"sessionid":"def","csrftoken":"uvw"}]
```

### Getting Your Session ID
1. Log in to instagram.com in Chrome
2. DevTools (F12) → Application → Cookies → `instagram.com`
3. Copy `sessionid`, `csrftoken`, `ds_user_id` values

---

## 🔑 Authentication

Every API request needs your API key:

```bash
# Header (recommended)
curl -H "x-api-key: YOUR_KEY" http://localhost:3000/api/v1/user?username=instagram

# Bearer token
curl -H "Authorization: Bearer YOUR_KEY" ...

# Query param
curl http://localhost:3000/api/v1/user?username=instagram&api_key=YOUR_KEY
```

---

## 📡 API Reference

### Universal Media Downloader

```
GET /api/v1/media?url=<any_instagram_url>
```

Pass **any** Instagram URL — post, reel, IGTV, carousel. The API auto-detects type and returns all download links at every available quality.

**Params:** `url` (required), `quality` (optional: `best` | `1080p` | `720p` | `480p` | `360p`)

**Response:**
```json
{
  "success": true,
  "cached": false,
  "detected_type": "reel",
  "shortcode": "ABC123xyz",
  "data": {
    "id": "3012345678901234567",
    "shortcode": "ABC123xyz",
    "url": "https://www.instagram.com/p/ABC123xyz/",
    "media_type": "video",
    "caption": "Caption text here...",
    "taken_at": 1709000000,
    "taken_at_iso": "2024-02-27T12:00:00.000Z",
    "like_count": 45231,
    "comment_count": 892,
    "play_count": 1200000,
    "owner": {
      "id": "123456789",
      "username": "someuser",
      "full_name": "Some User",
      "is_verified": true,
      "profile_pic_url": "https://..."
    },
    "video_downloads": [
      { "quality": "1080p", "width": 1080, "height": 1920, "url": "https://scontent.cdninstagram.com/..." },
      { "quality": "720p",  "width": 720,  "height": 1280, "url": "https://..." },
      { "quality": "480p",  "width": 480,  "height": 854,  "url": "https://..." }
    ],
    "thumbnail_url": "https://...",
    "duration_seconds": 29.5,
    "has_audio": true,
    "is_reel": true,
    "music": {
      "type": "licensed_music",
      "title": "Song Name",
      "artist": "Artist Name",
      "duration_ms": 30000,
      "audio_download_url": "https://...",
      "cover_art_url": "https://...",
      "is_explicit": false
    },
    "_selected_download": { "quality": "1080p", "url": "https://..." },
    "_source": "web_api_v1"
  }
}
```

### Batch Download

```
POST /api/v1/media/batch
Content-Type: application/json

{ "urls": ["https://instagram.com/reel/ABC/", "https://instagram.com/p/XYZ/"] }
```

Up to 10 URLs processed in parallel.

---

### Reels

```
GET /api/v1/reels?url=<reel_url>&quality=1080p
GET /api/v1/reels/user?username=<username>&cursor=<cursor>
GET /api/v1/reels/explore
```

---

### Stories ⚠️ Requires IG_SESSION_ID

```
GET /api/v1/stories?username=<username>
```

Returns active stories with both image and video download URLs.

---

### Highlights

```
GET /api/v1/highlights?username=<username>            # list all highlights
GET /api/v1/highlights/items?id=<highlight_id>        # items inside a highlight
```

---

### User Profile

```
GET /api/v1/user?username=<username>                  # full profile
GET /api/v1/user/posts?username=<username>            # recent posts feed
GET /api/v1/user/followers?username=<username>        # followers list ⚠ auth
GET /api/v1/user/followings?username=<username>       # followings list ⚠ auth
```

---

### Discovery

```
GET /api/v1/search?q=photography&type=blended         # search (users, hashtags, places)
GET /api/v1/hashtag?tag=photography                   # hashtag top posts
GET /api/v1/location?id=213385402                     # location posts
```

---

### Post Engagement

```
GET /api/v1/media/likers?shortcode=ABC123             # users who liked a post
GET /api/v1/media/comments?shortcode=ABC123           # post comments
GET /api/v1/media/audio?url=<reel_url>               # extract audio/music info
```

---

### Admin

```
GET /api/v1/status                                    # proxy pool, sessions, cache stats
GET /health                                           # uptime check
```

---

## 📄 Pagination

All list endpoints return a `pagination` object:

```json
{
  "pagination": {
    "has_more": true,
    "next_cursor": "QVFBc...",
    "total_count": 847
  }
}
```

Pass `cursor=<next_cursor>` to fetch the next page.

---

## 🛡️ Anti-Block Features

| Feature | Description |
|---|---|
| **5-Strategy Fallback** | web_api → graphql → mobile_api → html_scrape → oembed |
| **7 Browser Fingerprints** | Chrome Win/Mac/Linux, Firefox, Safari, Instagram Android/iOS apps |
| **Proxy Pool Rotation** | Round-robin with health tracking — bad proxies auto-skipped |
| **Session Pool Rotation** | Multiple IG accounts, round-robin |
| **Exponential Backoff** | Automatic retries with jitter on rate limits and server errors |
| **Human-Like Delays** | Random jitter on every request to avoid pattern detection |
| **429 Smart Handling** | Reads Retry-After header, waits exactly the right time |
| **Device ID Fingerprint** | Stable per-process device ID sent in X-Web-Device-Id |

---

## 🏗️ Architecture

```
src/
├── server.js                 # Express app, routing, rate limiting
├── core/
│   ├── httpEngine.js         # Anti-block HTTP engine (fingerprints, proxy, retries)
│   ├── strategies.js         # 5-strategy fallback media fetcher
│   └── normalizer.js         # Universal data normalizer (consistent output schema)
├── services/
│   └── instagram.js          # High-level orchestration (all public functions)
├── routes/
│   ├── media.js              # Universal + batch downloader, likers, comments, audio
│   ├── reels.js              # Reels download + explore + user reels
│   ├── stories.js            # Stories
│   ├── highlights.js         # Highlights list + items
│   ├── user.js               # Profile, posts, followers, followings
│   ├── search.js             # Search
│   ├── hashtag.js            # Hashtag feed
│   └── location.js           # Location feed
├── middleware/
│   ├── auth.js               # API key middleware
│   └── errorHandler.js       # Global error handler with IG-specific messages
└── utils/
    ├── cache.js              # In-memory cache (node-cache) with getOrSet helper
    └── logger.js             # Winston logger
```

---

## 🚢 Deployment

### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["node", "src/server.js"]
```

### PM2

```bash
pm2 start src/server.js --name ig-api -i max
```

### Environment Tips for Production

- Set `NODE_ENV=production`
- Use `PROXY_POOL` with 3+ residential proxies
- Use `IG_SESSION_POOL` with 2–3 accounts
- Set `CACHE_TTL=600` for user profiles
- Set `RATE_LIMIT_MAX_REQUESTS=200` if you trust your clients

---

## ⚠️ Disclaimer

This API uses Instagram's public and private-but-unauthenticated endpoints. Usage must comply with Instagram's Terms of Service. You are responsible for how you use this software. The authors accept no liability for account restrictions, IP bans, or legal consequences from misuse.
